from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import configparser
import requests
import urllib
import json
app = FastAPI()

# 設定ファイルから接続情報読み込み
conf = configparser.ConfigParser()
conf.read('conf/setting.conf')
API_KEY = conf['CRED']['API_KEY']

# HeartRails Expres/ 駅情報取得 API
# http://express.heartrails.com/api.html
# 都道府県、駅を指定し、緯度・経度を取得
def get_station_position(pref, station):
    api = 'http://express.heartrails.com/api/json?method=getStations&name={station_name}&prefecture={pref_name}'
    # URLエンコードした値をクエリパラメータ指定する
    url = api.format(station_name=urllib.parse.quote(
        station), pref_name=urllib.parse.quote(pref))
    res = requests.get(url)
    station_info = json.loads(res.text)['response']['station']
    station_lat = station_info[0]['y']
    station_lng = station_info[0]['x']
    return station_lat, station_lng

# Hotpepper グルメサーチAPI
# https://webservice.recruit.co.jp/doc/hotpepper/reference.html
# 緯度・経度を指定し、店舗情報を取得
def get_shops(lat, lng):
    api_base = "http://webservice.recruit.co.jp/hotpepper/gourmet/v1/?key={key}&lat={lat}&lng={lng}&range=2&order=1&format=json"
    api_url = api_base.format(key=API_KEY, lat=lat, lng=lng)
    response = requests.get(api_url)
    result_list = json.loads(response.text)["results"]["shop"]
    shops = []
    for shop in result_list:
        shops.append({"name": shop['name'], "url": shop['urls']['pc'],
                      "address": shop['address'], "open": shop['open']})
    return shops

# リクエストボディモデル定義
class SearchQuery(BaseModel):
    station: str
    pref: str

# API
@app.post("/search_shop")
def search_shop(query: SearchQuery):
    # リクエストボディに指定された都道府県、駅名を取得
    pref = query.pref
    station = query.station
    station_lat, station_lng = get_station_position(pref, station)
    return get_shops(station_lat, station_lng)
