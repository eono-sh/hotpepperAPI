import requests as rq
import json as js
import pprint

def test():
    result = rq.post('http://127.0.0.1:8000/search_shop', data = js.dumps({"station":"新宿","pref":"東京都"}))
    pprint.pprint(f"==[ result: {result.json()}")

if __name__=="__main__":
    test()
